function toggleMobileMenu() {
  document.querySelector("#menu").classList.toggle("active");
  document.querySelector(".mobile-bar").classList.toggle("active");
}

// FILE EKSKUL
